package com.chinalwb.are.spans;

import android.text.style.UnderlineSpan;

public class AreUnderlineSpan extends UnderlineSpan {

}
