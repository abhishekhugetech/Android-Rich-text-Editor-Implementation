package com.chinalwb.are.spans;

/**
 * Created by wliu on 2018/4/5.
 */

public interface AreDynamicSpan {
    public int getDynamicFeature();
}
