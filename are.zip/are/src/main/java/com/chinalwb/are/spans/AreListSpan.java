package com.chinalwb.are.spans;

import android.text.style.LeadingMarginSpan;

public interface AreListSpan extends LeadingMarginSpan {

}
