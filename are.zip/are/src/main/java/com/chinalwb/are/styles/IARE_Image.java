package com.chinalwb.are.styles;

import com.chinalwb.are.spans.AreImageSpan;

public interface IARE_Image {

    public void insertImage(final Object src, final AreImageSpan.ImageType type);
}
