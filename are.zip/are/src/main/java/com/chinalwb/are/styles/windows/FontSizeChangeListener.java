package com.chinalwb.are.styles.windows;

public interface FontSizeChangeListener {
    void onFontSizeChange(int fontSize);
}